package domain;

import java.util.Collection;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.SequenceGenerator;

@Entity
public class Person implements BaseEntity<Long> {

	@Id
	@SequenceGenerator(name = "person_id_generator", sequenceName = "person_id_seq", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "person_id_generator")
	private Long id;

	@Column(length = 64)
	private String firstName;

	@Column(length = 64)
	private String lastNamePa;
	
	@Column(length = 64)
	private String lastNameMa;
	
	@Column(length = 8)
	private String DNI;

	@ManyToMany
    @JoinTable(name="person_account")
	private Collection<Account> accounts;

	@Override
	public Long getId() {
		return id;
	}

	@Override
	public void setId(Long id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastNamePa() {
		return lastNamePa;
	}

	public void setLastNamePa(String lastNamePa) {
		this.lastNamePa = lastNamePa;
	}

	public String getLastNameMa() {
		return lastNameMa;
	}

	public void setLastNameMa(String lastNameMa) {
		this.lastNameMa = lastNameMa;
	}
	
	public String getDNI() {
		return DNI;
	}

	public void setDNI(String DNI) {
		this.DNI = DNI;
	}
	
	public Collection<Account> getAccounts() {
		return accounts;
	}

	public void setAccounts(Collection<Account> accounts) {
		this.accounts = accounts;
	}

}
