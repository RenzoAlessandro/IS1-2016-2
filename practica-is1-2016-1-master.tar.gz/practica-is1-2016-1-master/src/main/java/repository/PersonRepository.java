package repository;

import domain.Person;

public interface PersonRepository extends BaseRepository<Person, Long> {
}
