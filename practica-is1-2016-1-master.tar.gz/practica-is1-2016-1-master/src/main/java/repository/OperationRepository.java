package repository;

import domain.Operation;

public interface OperationRepository extends BaseRepository<Operation, Long>{
}
